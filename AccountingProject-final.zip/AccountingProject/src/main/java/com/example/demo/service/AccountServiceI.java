package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Account;

@Service
public interface AccountServiceI {
	
	public Account saveAccount(Account account);
	public List<Account> saveAccunts(List<Account> account);
	public List<Account> getAccounts();
	public Account getAccuntByCustName(String custName);
	public Account getAccuntByAccountNum(int accountNum);
	public String deleteAccount(int id);
	public Account updateAccount(Account account);
	public String withdrawAmount(int accountNum, int withdrawAmount);
	public String transfer(int accountNumOfSender, int accountNumOfReceiver, int transferAmount);
	public String amountCredited(int accountNum, int transferAmount);
}
