package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.demo.entity.Account;
import com.example.demo.repository.AccountRepository;

@Component
public class AccountService implements AccountServiceI {
	
	@Autowired
	private AccountRepository accountRepository;
	
	public Account saveAccount(Account account){
		return accountRepository.save(account);
	}
	
	public List<Account> saveAccunts(List<Account> account){
		return accountRepository.saveAll(account);
	}
	
	public List<Account> getAccounts(){
		return accountRepository.findAll();
	}
	
	public Account getAccuntByCustName(String custName){
		return accountRepository.findByCustName(custName);
	}
	
	public Account getAccuntByAccountNum(int accountNum){
		return accountRepository.findByAccountNum(accountNum);
	}
	
	public String deleteAccount(int accountNum){
		accountRepository.deleteById(accountNum);
		return "removed by accountNum!!!"+accountNum;
	}
	
	public Account updateAccount(Account account){
		Account existingAccount=accountRepository.findByAccountNum(account.getAccountNum());
		existingAccount.setAccountNum(account.getAccountNum());
		existingAccount.setBankName(account.getBankName());
		existingAccount.setCustName(account.getCustName());
		existingAccount.setBalanceAmount(account.getBalanceAmount());
		return accountRepository.save(existingAccount);
	}

	public String withdrawAmount(int accountNum, int withdrawAmount) {
		Account existingAccount=accountRepository.findByAccountNum(accountNum);
		if(existingAccount.getBalanceAmount() < withdrawAmount)
			return "Withdrawal failed due to insufficient amount in the account.";
		existingAccount.setBalanceAmount(existingAccount.getBalanceAmount()-withdrawAmount);
		accountRepository.save(existingAccount);
		return "Withdrawal Successfully";
	}

	public String transfer(int accountNumOfSender, int accountNumOfReceiver, int transferAmount) {
		Account PayeeAccnt=accountRepository.findByAccountNum(accountNumOfSender);
		Account senderAccnt=accountRepository.findByAccountNum(accountNumOfReceiver);
		if(PayeeAccnt==null || senderAccnt==null)
			return "Invalid Account Number please Check verify account number.";
		if(PayeeAccnt.getBalanceAmount()<transferAmount)
			return "transfer failed due to insufficient amount in the account.";
		PayeeAccnt.setBalanceAmount(PayeeAccnt.getBalanceAmount()-transferAmount);
		senderAccnt.setBalanceAmount(senderAccnt.getBalanceAmount()+transferAmount);
		accountRepository.save(PayeeAccnt);
		accountRepository.save(senderAccnt);
		return transferAmount+" Rs. is transfered Successfully to account "+senderAccnt.getAccountNum()+" successfully.";
	}
	
	public String amountCredited(int accountNum, int transferAmount){
		Account existingAccount =accountRepository.findByAccountNum(accountNum);
		existingAccount.setBalanceAmount(existingAccount.getBalanceAmount()+transferAmount);
		accountRepository.save(existingAccount);
		return "Rs. "+transferAmount+" is credited to account "+existingAccount.getAccountNum()+" Avbl Bal: Rs. "+existingAccount.getBalanceAmount();
	}
}
